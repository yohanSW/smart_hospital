package com.example.minji.smarthospital;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import static com.example.minji.smarthospital.R.styleable.View;

/**
 * Created by MINJI on 2017-10-13.
 */

public class Menu extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        ImageView back = (ImageView) findViewById(R.id.imageView) ;
        ImageButton care = (ImageButton) findViewById(R.id.imageButton_care);
        ImageButton gall = (ImageButton) findViewById(R.id.imageButton_gall);
        ImageButton data = (ImageButton) findViewById(R.id.imageButton_data);
        ImageButton analytic = (ImageButton) findViewById(R.id.imageButton_dataanalytic);
        ImageButton alarm = (ImageButton) findViewById(R.id.imageButton_alarm);
        ImageButton hp = (ImageButton) findViewById(R.id.imageButton_hp);
        ImageButton monitor = (ImageButton) findViewById(R.id.imageButton_monitor);


        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        care.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://220.70.2.33/hospital_room.php"));
                startActivity(intent);
            }
        });

        gall.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://220.70.2.33/test.php"));
                startActivity(intent);
            }
        });

        data.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://220.70.2.33/test3.php"));
                startActivity(intent);
            }
        });

        analytic.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://220.70.2.33:8080"));
                startActivity(intent);
            }
        });

        ////////////라즈베리파이에서 stream.php -> 복사해서 만들기 ////////////////////////
        monitor.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://220.70.2.33/"));
                startActivity(intent);
            }
        });

        alarm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://220.70.2.33/emergency.php"));
                startActivity(intent);
            }
        });

        hp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://220.70.2.33/"));
                startActivity(intent);
            }
        });
    }
}
